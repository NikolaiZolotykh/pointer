function dl_disp(dl)
% DL_DISP
%
%  DL_DISP(head) displays a doubly linked list using the traverse
%  routine:
%	    dl_trav(dl,'disp')
%

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

dl_trav(dl,'disp');

