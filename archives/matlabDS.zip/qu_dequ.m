function qu=qu_dequ(qu)
% QU_DEQU
%
%  qu=QU_DEQU(qu) pops the first element of the queue.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

qu=sl_del(qu);

