function st=st_new
% ST_NEW
%
%  st=ST_NEW returns an empty stack.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

st=sl_new;

