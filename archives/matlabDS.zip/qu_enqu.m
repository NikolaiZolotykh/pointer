function qu=qu_enqu(qu,x)
% QU_ENQU
%
%  qu=QU_ENQU(qu,x) inserts x as the last element in the queue.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

qu=sl_puta(qu,qu.tail,x);

