function rb_graph(rb)
% RB_GRAPH
%
%  RB_GRAPH(rb) shows a graphic representation of the red-black binary tree rb.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

bt_graph(rb);

