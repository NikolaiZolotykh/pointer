function sl_disp(sl)
% SL_DISP
%
%  SL_DISP(sl) displays a singly linked list using the traverse
%  routine:
%	    sl_trav(sl,'disp')

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

sl_trav(sl,'disp');

