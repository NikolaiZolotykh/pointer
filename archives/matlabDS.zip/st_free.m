function st=st_free(st)
% ST_FREE
%
%  st=ST_FREE(st) frees the memory allocated to the stack

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

st=sl_free(st);

