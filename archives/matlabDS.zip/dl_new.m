function dl=dl_new
% DL_NEW
%
%  dl=DL_NEW returns an empty doubly linked list.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

dl=sl_new;
dl.head.prev=0;

