function st=st_pop(st)
% ST_POP
%
%  ST_POP(st) pops the top element of the stack.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

st=sl_del(st);

