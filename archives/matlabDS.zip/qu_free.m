function qu=qu_free(qu)
% QU_FREE
%
%  qu=QU_FREE(qu) frees the memory allocated to the queue


% Copyright (c) MathTools Ltd. 1998. All rights reserved.

qu=sl_free(qu);

