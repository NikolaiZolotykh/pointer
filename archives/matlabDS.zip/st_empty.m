function z=st_empty(st)
% ST_EMPTY
%
%  z=ST_EMPTY(st) returns true if the stack is empty.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

z=sl_empty(st);

