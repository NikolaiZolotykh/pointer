function h=malloc

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

h=pointer;
