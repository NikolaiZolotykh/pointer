function node=avl_find(avl,key)

node=bt_find(avl,key);

