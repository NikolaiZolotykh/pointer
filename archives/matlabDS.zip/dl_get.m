function data=dl_get(dl)
% DL_GET
%
%  data=DL_GET(dl) returns the first element in a doubly linked
%  list.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

if nargin<1
  error('one input argument required.');
end
if nargin<1
  error('one output argument required.');
end

data=sl_get(dl);

