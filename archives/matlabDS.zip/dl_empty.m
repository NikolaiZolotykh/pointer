function z=dl_empty(dl)
% DL_EMPTY(dl)
%
%  z=DL_EMPTY(dl) returns true if the linked list is empty.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

z=sl_empty(dl);

