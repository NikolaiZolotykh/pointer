function z=qu_empty(qu)
% QU_EMPTY
%
%  z=QU_EMPTY(qu) returns true if the queue is empty.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

z=sl_empty(qu);

