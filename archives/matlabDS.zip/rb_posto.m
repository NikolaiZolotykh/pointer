function rb_posto(rb,func,varargin)
% RB_POSTO
%
%  RB_POSTO(rb,func,...) traverses the tree postorder,
%  calling func on every node data.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

bt_posto(rb,func,varargin{:});

