function qu=qu_new
% QU_NEW
%
%  qu=QU_NEW returns an empty queue.

% Copyright (c) MathTools Ltd. 1998. All rights reserved.

qu=sl_new;

