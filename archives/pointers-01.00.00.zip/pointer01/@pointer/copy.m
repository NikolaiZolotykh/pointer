% COPY	copies contents of the pointer
%
%   B = COPY(A) creates the pointer B containing the copy of the contents of pointer A
%
%   See also POINTERS, MALLOC, @POINTER\FREE, @POINTER\STRUCT

%   Copyright 2004 Nikolai Yu. Zolotykh

