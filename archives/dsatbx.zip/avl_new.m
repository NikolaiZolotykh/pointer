function avl=avl_new

avl=bt_new;

