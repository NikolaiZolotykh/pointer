function qu=qu_new
% QU_NEW
%
%  qu=QU_NEW returns an empty queue.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

qu=sl_new;

