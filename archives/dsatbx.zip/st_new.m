function st=st_new
% ST_NEW
%
%  st=ST_NEW returns an empty stack.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

st=sl_new;

