function y=st_top(st)
% ST_TOP
%
%  ST_TOP(st) returns the top element of the stack.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

y=sl_get(st);

