function qu=qu_dequ(qu)
% QU_DEQU
%
%  qu=QU_DEQU(qu) pops the first element of the queue.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

qu=sl_del(qu);

