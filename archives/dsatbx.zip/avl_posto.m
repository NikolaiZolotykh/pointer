function avl_posto(avl,func,varargin)

bt_posto(avl,func,varargin{:});

