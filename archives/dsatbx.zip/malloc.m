function h=malloc

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

h=pointer;
