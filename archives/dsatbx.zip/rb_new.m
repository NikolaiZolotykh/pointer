function rb=rb_new
% RB_NEW
%
%  rb=RB_NEW returns an empty red-black binary tree.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

rb=bt_new;

