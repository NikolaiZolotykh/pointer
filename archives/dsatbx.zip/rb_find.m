function node=rb_find(rb,key)
% RB_FIND
%
%  node=RB_FIND(rb,key) finds the node with key.
%  if key was not found, node=0.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

node=bt_find(rb,key);

