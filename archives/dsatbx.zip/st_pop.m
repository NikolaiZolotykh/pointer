function st=st_pop(st)
% ST_POP
%
%  ST_POP(st) pops the top element of the stack.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

st=sl_del(st);

