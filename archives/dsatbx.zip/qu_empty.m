function z=qu_empty(qu)
% QU_EMPTY
%
%  z=QU_EMPTY(qu) returns true if the queue is empty.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

z=sl_empty(qu);

