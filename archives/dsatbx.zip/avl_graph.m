function avl_graph(avl)

bt_graph(avl);

