function avl=avl_free(avl)

bt_free(avl);

