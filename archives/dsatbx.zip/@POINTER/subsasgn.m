function obj=subsasgn(obj,s,b)
mt_asgn1(obj,s,b);
