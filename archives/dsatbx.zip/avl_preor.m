function avl_preor(avl,func,varargin)

bt_preor(avl,func,varargin{:});

