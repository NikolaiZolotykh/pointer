function z=st_empty(st)
% ST_EMPTY
%
%  z=ST_EMPTY(st) returns true if the stack is empty.

% Copyright (c) MathWorks Inc. 1998-2001. All rights reserved.

z=sl_empty(st);

