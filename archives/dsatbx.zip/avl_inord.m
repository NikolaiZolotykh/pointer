function avl_inord(avl,func,varargin)

bt_inord(avl,func,varargin{:});

