% NE	ne function for pointers.

%   Copyright 2004 Nikolai Yu. Zolotykh
