% FREE	release memory
%
%   FREE(P) release memory occupied by pointer P
%
%   See also MALLOC, @POINTER\POINTER
%

%   Copyright 2004 Nikolai Yu. Zolotykh
