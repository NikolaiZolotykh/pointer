cd @pointer
mex assgn.c    utils.c
mex eq.c       utils.c
mex free.c     utils.c
mex ne.c       utils.c
mex pointer.c  utils.c
mex ref.c      utils.c
mex struct.c   utils.c
mex copy.c     utils.c
cd ..