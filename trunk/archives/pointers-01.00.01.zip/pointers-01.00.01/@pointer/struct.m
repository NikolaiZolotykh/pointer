% STRUCT	create a structure containing the copy of pointer contents.
%
%   S = STRUCT(P) create structure S containing the copy of contents of pointer P.
%
%   See also @POINTER\POINTER


%   Copyright 2004 Nikolai Yu. Zolotykh
